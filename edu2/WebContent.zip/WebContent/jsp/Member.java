package com.edu.test.stateless;

public class Member {
	private String memberId;
	private String memberPwd;
	private String memberName;
	private int memberAge;
	
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getMemberPwd() {
		return memberPwd;
	}
	public void setMemberPwd(String memberPwd) {
		this.memberPwd = memberPwd;
	}
	public String getMemberName() {
		return memberName;
	}
	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}
	public int getMember_age() {
		return memberAge;
	}
	public void setMember_age(int member_age) {
		this.memberAge = member_age;
	}
	
	
}
