package com.edu.test;

public class main {

	public static void main(String[] args) {
		InitparamServlet ips = new InitparamServlet();
		ips.id = "user";
	}

}
